package springboot.api.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import springboot.api.project.model.School;


@Repository
public interface SchoolRepository extends CrudRepository <School, Long>  {

}
