package springboot.api.project.controller;

import java.util.ArrayList;
import java.util.List;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import springboot.api.project.model.School;
import springboot.api.project.repository.SchoolRepository;

@RestController
@RequestMapping("/api")
public class schoolController {
	@Autowired
	SchoolRepository schoolRepository; 
	
	@GetMapping("/school")
	 public List<School> getAllSchools() {
	  final List<School> schoolList = new ArrayList<School>();
	  Iterable<School> iterable = schoolRepository.findAll();
	  iterable.forEach(schoolList::add);
	  return schoolList; 
	 }
	 
	 @GetMapping("/school/{id}")
	 public ResponseEntity<School> getProductById(@PathVariable(value = "id") Long id) {
	  Optional<School> school = schoolRepository.findById(id);
	  return school.isPresent() ? new ResponseEntity<School>(school.get(), HttpStatus.OK)
	    : new ResponseEntity("No data found", HttpStatus.NOT_FOUND);
	 } 
	 
	 @PostMapping("/school")
	 public School addSchool(@RequestBody School school) {
	  return schoolRepository.save(school);
	 } 
	 
	 @PutMapping("/school/{id}")
	 public ResponseEntity<School> updateSchool(@PathVariable(value = "id") Long id, @RequestBody School newschool) {
	  Optional<School> school = schoolRepository.findById(id); 
	  
	  if (school.isPresent()) {
	  School sch = school.get();
	   sch.setSchoolname(newschool.getSchoolname());
	   sch.setAddress(newschool.getAddress());
	   sch.setContactno(newschool.getContactno());   
	   sch = schoolRepository.save(sch);
	   return ResponseEntity.ok().body(sch);
	  } else {
	   return ResponseEntity.notFound().build();
	  }
	  
	  
	 } @DeleteMapping("/products/{id}")
	 public ResponseEntity<School> deleteProduct(@PathVariable(value = "id") Long id) {
	  Optional<School> school = schoolRepository.findById(id);  
	  
	  if (school.isPresent()) {
		  schoolRepository.delete(school.get());
	   return new ResponseEntity("School has been deleted successfully.", HttpStatus.OK);
	  } else {
	   return ResponseEntity.notFound().build();
	  }
	 }  
    
}
