package springboot.api.project.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="school")
@EntityListeners(AuditingEntityListener.class)

public class School {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="schoolname")
	  private String schoolname;
	  
	@Column(name="address")
	  private String address;
	  
	@Column(name="contactno")
	  private Long contactno;
    	
	@Column(name="email")
	  private String email;

	
	public School() {
	}
    
	
	public School(Long id, String schoolname, String address, Long contactno, String email) {
		this.id = id;
		this.schoolname = schoolname;
		this.address = address;
		this.contactno = contactno;
		this.email = email;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSchoolname() {
		return schoolname;
	}

	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getContactno() {
		return contactno;
	}

	public void setContactno(Long contactno) {
		this.contactno = contactno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	
	
   	
	
	  
}
